"""
ORCA-MI - Python API
====================
Author: Yazdan Salimi (salimiyazdan@gmail.com) - built with the help of Jean-Claude (Claude by Anthropic)

Control the ORCA-MI viewer from Python, Jupyter or scripts.
Only the standard library is required (numpy only if you pass arrays).

Two ways of calling it
----------------------
1. ``launch(...)``   start a viewer with command-line options (fire and forget)::

       import orcami as om
       om.launch("ct.nii.gz", overlay="pet.nii.gz", seg="organs.nii.gz",
                 layout="mpr", mode3d="dvr", theme="nord")

2. ``Viewer()``      live connection; every viewer command is a Python method and returns results::

       v = om.Viewer()                       # starts the viewer (or connects to a running one)
       v.load("ct.nii.gz")                   # role="image"
       v.load("pet.nii.gz", role="overlay", colormap="hot iron", opacity=0.5)
       v.load("organs.nii.gz", role="seg", palette="turbo", opacity=0.6)
       v.load(my_array, spacing=(2, 2, 2), name="prediction", role="overlay")   # numpy arrays work too
       v.threshold(2.5, 1000)
       print(v.stats())                      # list of dicts (volume, mean, max, peak, ...)
       v.layout("mpr"); v.mode3d("dvr")
       v.run_ai(preset=0, model="D:/models/BestValidationMetricModel-Full.pth")
       v.close()

``Viewer.help()`` lists every command. Unknown attributes are forwarded as commands, so
``v.some_command(a, b)`` sends ``"some_command a,b"``.
"""

from __future__ import annotations

import gzip
import json
import os
import shutil
import socket
import struct
import subprocess
import sys
import tempfile
import time
from typing import Any, Iterable, Optional, Sequence

__all__ = ["launch", "Viewer", "OrcaMIError", "COMMANDS", "find_exe", "write_nifti"]
__version__ = "1.0.0"

DEFAULT_PORT = 47654

# Every command understood by the viewer (script files, --options and this API).
COMMANDS = {
    # files & data
    "open": "open <path> – open a file or folder (DICOM folders go to the DICOM browser)",
    "load": "load <path>|role=image|colormap=..|opacity=..|palette=..|vp=..|window=lo,hi|name=..",
    "overlay": "overlay <path>|colormap=..|opacity=.. – load as fusion overlay",
    "seg": "seg <path>|palette=..|opacity=.. – load as segmentation of the displayed image",
    "loaddicom": "loaddicom <folder> – scan a folder and load all image series",
    "viewports": "viewports – what every view shows ([viewport] vp=|kind=|image=|overlay=, image indices)",
    "viewsegopacity": "viewsegopacity <0..1|own>[|vp=<i>] – segmentation opacity in one view only (own = the Segment tab's)",
    "showall": "showall <image index> – that image in every view of the layout (fusions removed)",
    "fuseall": "fuseall <overlay image index>[|opacity=x] – fused on every view of the layout (as right-click ⊕ Fusion overlay)",
    "image3d": "image3d <image index>[|fused=0|1] – the 3D view(s) show that image (alone unless fused=1)",
    "listimages": "listimages – list loaded images",
    "closeimage": "closeimage <index>",
    "closeall": "closeall – close every image",
    "select": "select <index> – make an image active",
    "nickname": "nickname <text> – nickname of the active image; nickname auto[=modality,date,scanner] – from the DICOM header (modality--date--scanner)",
    # display
    "layout": "layout 1|1x2|2x1|2x2|1x3|3x3|4x4|5x5|1+3|mpr|dualmpr",
    "fuse": "fuse – show image 1 fused on image 0",
    "view": "view axial|coronal|sagittal|3d – orientation of the active viewport",
    "activevp": "activevp <n> – choose the active viewport",
    "window": "window <lo>,<hi>",
    "colormap": "colormap <name>",
    "overlaycolormap": "overlaycolormap <name>",
    "overlayopacity": "overlayopacity <0..1>",
    "nooverlay": "nooverlay – remove the fusion overlay of the active viewport",
    "cursor": "cursor <x>,<y>,<z> – world position in mm (LPS)",
    "modelremove": "modelremove <preset index | name> – remove a model from ORCA-MI's list; its folder and files stay on the disk",
    "study": "study – list the studies ([study] date=…|desc=…|uid=…|images=0,2); study <i>|of=<j> – image i into the study of image j; study <i>|new=YYYY-MM-DD|desc=… – a new study; study <i>|none",
    "probe": "probe [x,y,z] – value of every image at the crosshair (or at that world point, LPS mm): [probe] index=…|name=…|voxel=i,j,k|value=…|unit=…|labels=…; probe window – the floating window",
    "slice": "slice <+-n> – move slices",
    "theme": "theme <name>",
    "appearance": "appearance [open|close|<style>] – the Appearance page; styles: ORCA Standard, Clinical reading room, Research compact, Presentation, Soft teal",
    "countryconsent": "countryconsent 0|1 – answer the country question (sent once, from Windows' region setting)",
    "language": "language en|fr – interface language (displayed texts only; scripts, names and results stay English); prints [language]",
    "trfr": "trfr <text> – prints [trfr] with the French interface text",
    "opaque3d": "opaque3d on|off – opaque background behind the 3D view's checkboxes; prints [opaque3d]",
    "toolcursor": "toolcursor on|off – the mouse pointer shows the selected tool on the views; prints [toolcursor]",
    "nnmip": "nnmip on|off – nnInteractive Point clicks on the 3D MIP of PET / SPECT images (brightest voxel on the clicked line); prints [nnmip]",
    "objpick": "objpick keep|remove|off [x,y,z] – keep / remove the object clicked on a view (or at that voxel of the active image at once); prints [objpick]",
    "tool3d": "tool3d 0|1|2 – 3D view tool: rotate, remove object, 3D eraser; prints [tool3d]",
    "erase3d": "erase3d <mm> – radius of the 3D eraser; prints [erase3d]",
    "userstats": "userstats 0|1|show|privacy – usage statistics per user (licensed; 0 withdraws and deletes the rows at the author); show prints [userstats] with what is sent",
    "countryreport": "countryreport – print what the country report would send ([country] {...}); sends nothing",
    "tab": "tab image|segment|3d|register|ai|scores|info",
    "mode3d": "mode3d mip|minip|dvr|iso|seg",
    "crosshair3d": "crosshair3d boxes|lines|off – crosshair in 3D views: lines + slice outlines, lines only, hidden",
    "removetable": "removetable on|off – hide the CT table in 3D",
    "view3d": "view3d reset|anterior|posterior|left|right|superior|inferior – 3D camera",
    "cpu3d": "cpu3d – CPU 3D renderer",
    "gpu3d": "gpu3d – GPU 3D renderer",
    "rotate3d": "rotate3d <yaw>,<pitch>,<zoom>",
    "snapshot": "snapshot <png path> – save the active viewport",
    # segmentation
    "newseg": "newseg <name>",
    "label": "label <value> – active label",
    "threshold": "threshold <lo>,<hi>",
    "morph": "morph erode|dilate|open|close,<radius mm>",
    "keeplargest": "keeplargest <n>",
    "fillholes": "fillholes",
    "splitcomponents": "splitcomponents",
    "segpalette": "segpalette distinct|<colormap>|#rrggbb|red|green...",
    "segopacity": "segopacity <0..1>",
    "segoutline": "segoutline on|off",
    "stats": "stats – statistics of every label",
    "metrics": "metrics a_img,a_seg,a_label,b_img,b_seg,b_label[,all] (all=1: every label of A and their mean over all labels)",
    "printmetrics": "printmetrics",
    "save_seg": "save_seg <path> (.nii.gz .nrrd .mha .dcm .stl)",
    "save_image": "save_image <path> (no extension = DICOM series folder)",
    # nnInteractive
    "nnstart": "nnstart – start nnInteractive",
    "nnpoint": "nnpoint max|cursor|<x>,<y>,<z> – positive click",
    "nnneg": "nnneg max|cursor|<x>,<y>,<z> – negative click",
    "nnnext": "nnnext – next object",
    # registration
    "regpair": "regpair <fixed index>,<moving index>",
    "center": "center geometric|mass",
    "translate": "translate <x>,<y>,<z>",
    "rigid": "rigid mi|ncc|mse",
    "deformable": "deformable",
    "printtransform": "printtransform",
    # AI
    "aipreset": "aipreset <index>",
    "aimodel": "aimodel <path> – model file / nnU-Net folder of the selected preset",
    "ai": "ai <preset index> – run on the active image",
    # PET / scoring
    "suv": "suv – convert active PET to SUVbw (new image)",
    "annotate": "annotate <text> – point annotation at the cursor",
    "score": "score <criterion>,<value>",
    # database
    "pacsadd": "pacsadd <folder>",
    "pacsindex": "pacsindex [full]",
    "pacsopen": "pacsopen",
    "pacsfilter": "pacsfilter <text>",
    "lesionmark": "lesionmark new|gone <pair> <lesion> [off] – mark a lesion new at time point pair+1 / disappeared at pair+1; prints [lesionmark]",
    "pacsgroup": "pacsgroup name|id|year|month – how the patient database lists its studies",
    "pacsrange": "pacsrange any|today|7|30|92|365|1827 – date range of the patient database (days back)",
    "pacsmodality": "pacsmodality <MOD>|All – modality filter of the patient database",
    "pacsloadstudy": "pacsloadstudy <search text> – load the first matching study",
    # dosimetry
    "dose": "dose <image index> – dose image for DVH / isodose",
    "dosescale": "dosescale <factor> – multiply dose values to get Gy (0.01 for cGy)",
    "rx": "rx <Gy> – prescription / reference dose",
    "structures": "structures <image index>,<segmentation index>",
    "dvh": "dvh – compute DVHs",
    "printdvh": "printdvh – DVH metrics per structure",
    "scoredb": "scoredb <root>|reference=reference|reader=Dr A[,Dr B]|order=patient|random|inorder|criteria=<file.json>|layout=auto|one|mpr|side|2x2|dualmpr|base=anatomical|functional|functional_only|view3d=functional|anatomical|title=…|save=1 – score a patients/configurations database (save=1: write the set-up, a session and a shortcut per reader into it)",
    "scoredbdialog": "scoredbdialog [<folder>] – open the Score a database window",
    "scoring": "scoring <file> – open a scoring shortcut (.orcascore), scoredb.json or a reader's session file, as a double-click does",
    "scoringpick": "scoringpick <reader> – choose the reader in the 'who is scoring?' window and start",
    "resultsload": "resultsload <folder> – load the saved scores of a study into the Results tab",
    "resultsshow": "resultsshow <k> – show result k on its images with its annotations",
    "session": "session <file.json|csv|xlsx> – open a reading session",
    "sessionnext": "sessionnext – save the case and go to the next one",
    "sessionsave": "sessionsave",
    "sessionend": "sessionend – save and close the session (writes the summary CSV)",
    "results": "results <folder> – load saved case results into the Results tab",
    "installmodel": "installmodel <preset index or name>[|url][|folds=0,1] – download + install a model (zip extracted); folds= only these folds of a catalog model",
    "installenv": "installenv [auto|cpu|cu126|cu128] – install private Python + PyTorch + nnU-Net/nnInteractive/MONAI",
    "modelmanifest": "modelmanifest <url of models.json> – fetch the online model list",
    "modellibrary": "modellibrary [segmentation|image|other|nninteractive] – open the model library window (on that tab)",
    "contrast": "contrast 0..3 – contrast level on top of the theme",
    "train": "train <imagesTr/labelsTr folder>|name=My model|epochs=100|folds=0,1|config=3d_fullres|network=default|resenc_m|resenc_l|channels=CT – train an nnU-Net in the background",
    "finetune": "finetune <imagesTr/labelsTr folder>|name=...|epochs=20|iters=100|lr=3e-5|patch=0|device=cuda|workers=8|batch=2|cache=64|checked=30|skip_baseline=0|eval=1|eval_all=0 – fine-tune nnInteractive",
    "logsearch": "logsearch <text> – number of lines of ORCA-MI's log that contain the text ([logsearch] n=…)",
    "trainstop": "trainstop <k> – stop training run k (0 = newest); traincontinue <k> – resume it from its checkpoint",
    "traincontinue": "traincontinue <k> – resume training run k (0 = newest) from its last checkpoint",
    "traineval": "traineval <k> – (re)compute the evaluation of nnInteractive fine-tuning run k (0 = newest): original vs fine-tuned model, segment metrics and lesion matching ([evalrow] lines)",
    "trainings": "trainings – status of all training runs",
    "presets": "presets – list AI model presets",
    "aidiagnose": "aidiagnose [download] – report of Python / PyTorch / CUDA / nnU-Net / nnInteractive / internet (ai_diagnostics.txt); prints [aiversion] <package> installed= tested=",
    "python": "python <path to python.exe> – Python used by nnInteractive and all AI models",
    "nndevice": "nndevice cuda|cpu",
    "nnispeed": "nnispeed accurate|fast|ultrafast (nnInteractive speed; applied at once; prints [nnispeed])",
    "nnoverwrite": "nnoverwrite shared|all|none|only=2,3 (what nnInteractive may paint over; none = only empty voxels; prints [nnoverwrite])",
    "combinelabels": "combinelabels [label] (every label of the active segmentation becomes this one, default the active label; undo-able; prints [combinelabels])",
    "nnmodel": "nnmodel <name>|official|list|download <name> – nnInteractive model in use; list / download the fine-tuned ones",
    "iterative": "iterative value=1|seg=0|mode=lesions|labels|boxes|margin=10|plateau=2|post=10|maxiter=500|step=0.1|minvol=0|largest=1|rough=1 – iterative threshold segmentation (XEOS)",
    "iterthreshold": "iterthreshold <lesion>,<threshold|auto> – change one lesion's threshold",
    "packages": "packages – AI packages installed in the current Python",
    "installpackages": "installpackages nninteractive,monai – pip install into the current Python (PyTorch kept)",
    "show3d": "show3d image=0|seg=1 – show / hide the image volume and the segmentation in 3D",
    "dynamic": "dynamic frames=<i>|images=<i,j,k>|ref=<k>|seg=<i>|times=..|durations=..|unit=min|register=1|from=<frame>|input=<label>|tstar=10|tail=2|csv=<path>|kimap=1|corrected=1",
    "segtarget": "segtarget <image index>[|seg=k] (active segmentation, shown and edited on every image)",
    "nnimage": "nnimage <image index> | nnimage auto (image nnInteractive segments)",
    "labelview": "labelview <label>|a=1|s=1|c=1|3d=0 (per-view visibility)",
    "requestclose": "requestclose (like the window close button: asks to save unsaved work); quit closes without asking",
    "drop": "drop <file or folder>|role=overlay|vp=<i> (like dropping on the window; overlays go to all views, layout kept)",
    "layoutinfo": "layoutinfo (prints the layout and the image + overlay of each view)",
    "ctdose": "ctdose size|engine=builtin|yazdan|phantom=32|csv=<file> (exposure per slice, water-equivalent diameter, SSDE)",
    "compare": "compare ref=<i>|eval=<i>|mask=<i>:<seg>:<label>|maskmode=yazdan|regions=<i>:<seg>|clip=lo,hi ([compare] metrics, [region] rows)",
    "comparemaps": "comparemaps percent=0|1 (bias or % bias map as a new image)",
    "gamma": "gamma dd=3|percent=1|dta=3|cutoff=10|sub=1|poole=0|signed=0 (gamma map + pass rates of the compare images)",
    "nps": "nps image=<i>|mask=<i>:<seg>:<label>|roi=64|overlap=1|detrend=mean|plane (noise power spectrum)",
    "profile": "profile a=x,y,z|b=x,y,z|frame=<i>|images=0,1|step=0|nearest=0|baseline=1|legend=0:CT;1:PET|font=1.5|csv=<file>|svg=<file>",
    "modeltree": "modeltree <folder> (scan a model folder tree, e.g. Google Drive, and add the models)",
    "checkupdates": "checkupdates [endpoint] (fetch news and new models now)",
    "regname": "regname <name> (name of the next registration result)",
    "reglist": "reglist (saved registrations: [reg] index|name|kind|…)",
    "regapply": "regapply image=<i>|tf=<k>|new=0|1|name=<new name>|segs=1 (apply a saved registration)",
    "regcombine": "regcombine 0,1,2|name=<name> (combine saved registrations, in the order made, into one; prints [regcombine] tf=<k>)",
    "resample": "resample 1.5 | 1,1,3|interp=nearest|linear|bspline|clip=1|segs=1|name=…|image=<i>  (new voxel spacing in mm: a new image in place of the original; prints [resample] …; without arguments: moving onto the fixed grid)",
    "filter": "filter gaussian|fwhm=4 · median|window=5 · mean|window=3 · bilateral|sigma=2|range=50 · diffusion|iter=10|k=30|dt=0.06 · nlm|h=20|search=2|patch=1 · butterworth|cutoff=0.8|order=5  (+ |2d=1 |new=0 in place |name=… |image=<i>)",
    "regpreview": "regpreview 0|1 (moving image shown in the fixed space on its own views while registering)",
    "regmouse": "regmouse 0|1 (move / rotate the moving image with the mouse on fused views)",
    "regturn": "regturn axial|coronal|sagittal <deg> – turn the moving image clockwise in that plane about the crosshair (arrow buttons); prints [regturn]",
    "regundo": "regundo – undo the last manual move (mouse or arrow buttons); prints [regundo]",
    "regpick": "regpick on|off – click landmark pairs on the views (align by points); prints [regpick]",
    "regnudge": "regnudge dx,dy,dz | regnudge rot=z,5 (move / rotate the moving image as the mouse does, about the crosshair)",
    "regpoint": "regpoint fixed|moving x,y,z [pair 1-10] (landmark in that image's world)",
    "regpoints": "regpoints [rotate=0|1][|refine=0|1] (align on the landmark pairs: 1 = translation, 2+ = rigid; refine = local image matching of each point)",
    "regdualmpr": "regdualmpr (Register: fixed image in the left MPR, moving image in the right one)",
    "regcentermask": "regcentermask <img>:<seg>:<label>|<img>:<seg>:<label> (align the centres of a fixed and a moving segment)",
    "report": "report lesions|stats|compare|folder=<dir>|name=<name>|csv=1|xlsx=1|png=1|svg=1|html=1|json=1|log=1|anon=0|measures=volume,max,mean (a report folder; prints [report] dir=…|files=n)",
    "lesionplot": "lesionplot 1|0 (lesion progress plots)",
    "recentfiles": "recentfiles 1|0 (window with every recent file)",
    "samescale": "samescale 0|1 (1, default: 2D views of one orientation share the mm-per-pixel scale)",
    "removefusion": "removefusion (remove fused overlays from every view)",
    "lesiontrack": "lesiontrack base=<i>|bmask=<i>:<s>:<label>|fu=<i>|fmask=…|bliver=…|fliver=…|tf=<saved k>|dist=25|minml=0.1|conn6=0 (find lesions, suggest links; label 0 = every label except liver); more follow-ups: fu2=|fmask2=|fliver2=|tf2= … fu9, n=<time points>",
    "separate": "separate <image>:<seg>:<label 0 = every label>|conn6=0|minml=0 (each connected region its own label, in a new segmentation '<name> (separated)')",
    "regfuseall": "regfuseall 0|1 (1: registration results fused on every view of the fixed image; 0, default: keep the layout)",
    "gotoseg": "gotoseg [label] (crosshair to the centre of the active segmentation, or of one label)",
    "cursorinfo": "cursorinfo (prints the crosshair of each view, in its image's world)",
    "segdb": "segdb <root>|user=<observer>|anon=1|view=fused|side|single|channels=ct,pet|on=<image name part>|title=…|labels=1:Lesion soft tissue:#ff0000,2:…|score=1|from=<other observer>|nnunet=<AI-tab model>|layout=mpr|one|auto|base=segmented|anatomical|functional|functional_only|view3d=functional|anatomical|cmapf=Hot iron|cmapa=Grayscale|comment=…|description=…|readers=Dr A,Dr B|nnreader=<name>|nnspeed=ultrafast|fast|balanced|accurate|nnconfig=<configuration folder>|nndevice=cpu|shortcuts=1 (segment a database; done studies of this user are skipped; nnunet= with nnreader= makes an nnU-Net reader; prints [segdb], [segdbshortcuts])",
    "nnprep": "nnprep root=<segmented database>|out=<nnUNet_raw folder>|name=<Name>|id=<1…999>|readers=Dr A,Dr B (empty = every reader)|combine=<name> (majority vote of the readers, saved as reader <name>)|allonly=0|channels=<image name part>:<channel name>,… (part empty = the segmented image)|skipnormal=1|overwrite=1|window=1 (nnU-Net v2 raw dataset DatasetNNN_Name from the saved segmentations; prints [nnprep])",
    "segdbdialog": "segdbdialog [folder] (opens the Segment a database window)",
    "segdbscore": "segdbscore <criterion>=<value>|… (scores of the loaded study)",
    "segdbnext": "segdbnext (save the study and open the next one not done)",
    "segdbskip": "segdbskip (next study without saving)",
    "segdbgo": "segdbgo <n> (save and open study n, 1-based)",
    "segdbnormal": "segdbnormal (normal scan: save an empty segmentation, marked normal, and open the next study)",
    "segdbsave": "segdbsave (save the study's segmentation)",
    "segdbend": "segdbend (save and stop)",
    "segdbinfo": "segdbinfo (prints position, studies done, target image)",
    "lesionlink": "lesionlink <B>,<F> | pair=<k>|<a>,<b> | all | unlink <k> | goto <k> | approve (confirm / remove links, show lesion Lk)",
    "lesionreport": "lesionreport (per lesion, RECIST 1.1, PERCIST 1.0, TMTV and TLG; several follow-ups: [track] lines and one [recist] / [percist] / [tmtv] per follow-up)",
    "matchspace": "matchspace image=<i>|ref=<i>|interp=linear|nearest|default=0|segs=1 (resample onto another grid)",
    "maskimage": "maskimage image=<i>|seg=<i>:<s>:<label>;…|value=0|invert=0|crop=0 (mask an image to segments)",
    "view3dmask": "view3dmask on|off (3D image only inside the segments shown in 3D)",
    "aicrop": "aicrop body=1|margin=10|z=lo,hi|off (crop the AI input to the body / a z-range; prints the box)",
    "colorbar": "colorbar on|off [overlay] | colorbar all on|off",
    "lutgamma": "lutgamma <gamma> (colormap contrast curve of the active image)",
    "scale": "scale <factor>|new=1|unit=<unit> (multiply the active image)",
    "braineir": "braineir pet=<index>|gm=<img>:<seg>:<label>|wm=<img>:<seg>:<label>|min=0.1|max=15|step=0.1|gmv=1|wmv=0.25|out=<folder>|dro=1 (brain PET EIR, as yazdan.Brain_EARL.calculate_curve_and_resolution; prints [braineir])",
    "braineirwindow": "braineirwindow (open the Brain PET resolution window)",
    "batchsearch": "batchsearch source=<folder>|pattern=*/**/*.nii.gz|exfile=a,b|exfolder=c|add=1 (Batch tab: files found like glob(recursive=True), ticked ones added with add=1; prints [batchsearch] and [batchfound])",
    "batchout": "batchout folder=<dir>|next=0|prefix=|suffix=_seg|ext=.nii.gz|keep=1|base=<folder>|levels=0 (Batch output names / folders; prints [batchout] duplicates= and [batchoutput] lines)",
    "batchclear": "batchclear (remove all Batch inputs)",
    "unsaved": "unsaved (what closing ORCA-MI would ask about: [unsaved] n=… and one line per item)",
    "viewtext": "viewtext corner=12|orient=14|topright=1|trsize=12|bold=0|bg=0 (sizes of the corner text and orientation labels, the top-right block: show, size, bold, background; prints [viewtext])",
    "sysmon": "sysmon (one reading of the computer: prints [sysmon] cpu=…|cpu_name=…|ram_used_gb=…|gpu=…|vram_used_gb=…) · sysmon window · sysmon bar=0|1 (top-bar strip) · sysmon mode=all|names|icon",
    "dualthr": "dualthr a=<index>|b=<index>|alo=|ahi=|blo=|bhi=|op=and|or|name=<label>|label=<value, else new>|limit=<img>:<seg>:<label>|limitmode=inside|outside (double threshold of two images into one label of A; prints [dualthr])",
    "imagemath": "imagemath <A index>|<B index>|op=add|sub|factor=1|name=<text> (new image A ± factor·B on the grid of A)",
    "qspect": "qspect scanner=<name>|isotope=Lu-177|recon=<name>|time=<s>[|image=<index>] – Q.SPECT image from the active (or given) SPECT (time: per projection or total, as the scanner; from DICOM if omitted)",
    "qspectfactor": "qspectfactor scanner=<name>|kind=projection|total|recon=<name>|isotope=Lu-177|cf=<value>|ref=<s>|unit=Bq/mL|comment=…|reconcomment=…|scannercomment=…|manufacturer=…|model=… – add / update a scanner, reconstruction and CF",
    "qspectlist": "qspectlist – the Q.SPECT scanners and conversion factors",
    "qspectexport": "qspectexport <file.json> – export the Q.SPECT library",
    "qspectimport": "qspectimport <file.json> – add the scanners and CFs of an exported library",
    "qspectwindow": "qspectwindow [list] – open the Q.SPECT window (list: also the scanner list)",
    "decay": "decay nuclide=Lu-177|from=yyyy.mm.dd hh:mm:ss|to=yyyy.mm.dd hh:mm:ss|new=1 – decay-correct the active image from its acquisition time (from; default: DICOM) to a target time (halflife=<s> instead of nuclide)",
    "decaycalc": "decaycalc activity=100|unit=MBq|nuclide=Lu-177|from=…|to=…|out=mCi – activity at another time (Bq, kBq, MBq, GBq, µCi/uCi, mCi, Ci)",
    "decaywindow": "decaywindow – open the decay correction window",
    "nemazoom": "nemazoom 1.25|125% – interface size of the NEMA IEC window only (0.5 … 3)",
    "nemawindow": "nemawindow – open the NEMA IEC phantom analysis window (the active PET/SPECT and a CT of the same study are added)",
    "nema": "nema session=<file.json>|out=<folder>|reader=nema|orca|json=<results.json> – headless NEMA IEC analysis of a saved session (report export to out)",
    "nemaadd": "nemaadd [keep=0] [show] – send the loaded PET/SPECT and CT images to the NEMA IEC window with the default roles (keep=0: without their colormaps / windows; show: only open the dialog)",
    "nemaseg": "nemaseg – the active image's segmentation becomes the NEMA ROIs (labels 1-6 spheres, 7 background, 8 lung)",
    "nemasend": "nemasend – the NEMA ROIs become a segmentation 'NEMA ROIs' in ORCA-MI",
    "dicomconvwindow": "dicomconvwindow – open the batch DICOM → NIfTI conversion window",
    "dicomconvert": "dicomconvert <folder>[;<folder>…]|out=<folder>|same|modalities=ct,pt|all|workers=4|pattern=modality:0,study:4,series:4|sep=-- – batch DICOM → NIfTI (+ Excel, SUV) with the saved converter settings; pattern fields: modality, study, study_date, study_time, series, acquisition_date, acquisition_time, age, sex, scanner, recon (field:letters, 0 = all)",
    "convertformat": "convertformat type=float32|float64|int32|int16|uint16|uint8|rescale=0|new=1 – convert the data type (integers: round + clip, or rescale min…max onto the type's range)",
    "clip": "clip lo=<value>|hi=<value>|new=1 – clip the values (either bound may be left out)",
    "normalize": "normalize src=minmax|minp99|p1p99|manual|min=…|max=…|to=0,1|clip=1|new=1 – linear normalisation onto a target range",
    "percentiles": "percentiles 67,95|ignorezero=0|allframes=0 – exact percentiles (always with p1, median, p99)",
    "arms": "arms (arms position of the active CT)",
    "armsfile": "armsfile <CT file or DICOM folder> (arms position, CSV row)",
    "doseexport": "doseexport <file.xlsx | file.csv> (Dosimetry tab: every section with results, a sheet each in Excel)",
    "isoimage": "isoimage <image index | dose>|scale=<factor to Gy> (image of the isodose lines)",
    "ctexport": "ctexport <file.xlsx | file.csv> (CT dose tab: summary, regional statistics and per-slice values)",
    "nnobjects": "nnobjects boxnew=0|1|samelabel=0|1 (nnInteractive: each new box = a new object of the same label; Next object keeps the label)",
    "modelinfo": "modelinfo [preset index] (AI tab: read the model folder again: labels, channels, configurations, folds)",
    "postbody": "postbody [target=<img>:<seg>]|[body=<img>:<seg>:<label>] (AI tab post-processing: remove outside the body contour)",
    "postuldct": "postuldct [img=<i>]|[arms=0|1] (combine the five low-dose CT organ sets into 22 organs; arms cleaning off by default)",
    "postfdg": "postfdg [img=<i>]|[arms=0|1] (combine the three FDG PET organ sets with the low-dose CT organ values; prints [postfdg])",
    "postundo": "postundo (undo the last post-processing step)",
    "labelvisible": "labelvisible <label> 0|1 (show / hide a label of the active segmentation)",
    "frametime": "frametime (duration of the last frames in ms, tests)",
    "stp": "stp img=<i>|hours=<h>|nuclide=Lu-177|factor=1|decaycorr=0|density=1|energy=<MeV>|halflife=<h>|duration=<min>|segs=<img>:<seg>;...|teff=<segment / label>=<h>;... (single time point dosimetry: Hanscheid dose map + Madsen per segment)",
    "ct3d": "ct3d <preset>|off (CT colour presets in 3D: Bones, Bones B/W, Bones and skin 1, Bones and skin 2, Bones, muscles and skin, Angio, Airways and lungs, Skin B/W, MIP B/W, MIP B/W inverse)",
    "panelout": "panelout right|left[|0] (the whole tool panel / image list in its own window; |0 = back)",
    "windowstate": "windowstate [max|restore] (maximize / restore down the main window; reports its size)",
    "colorful": "colorful on|off (colourful appearance: fast / balanced / accurate … in their own colours)",
    "viewpicture": "viewpicture <file.gif|png|jpg>[;<file>] (ORCA-MI's picture viewer: GIFs play)",
    "picture": "picture next|prev|play|pause|frame <n>|speed <x>|close|status (the picture viewer)",
    "measurements": "measurements (the drawn distances of the active view's image, mm)",
    "anonymize": "anonymize src=<folder>[;<folder>]|out=<folder>|prefix=ANON|uids=0|1|private=0|1|birth=keep|year|remove|decode=<file>|csv=0|1|xlsx=0|1 (anonymized DICOM copies + decode file; counts only)  ·  anonymize window",
    "anondecode": "anondecode <decode .json/.csv/.xlsx>[|reveal=1] (load a decode file into the anonymizer window; counts only)",
    "record": "[camera: record start|cam=1|camdev=<part of name>|micdev=<part of name>|corner=0-3|camsize=0-2|round=0|1 · record cam 0|1 · record devices · pointer=arrow|circle|none|clicks=0|1|keys=0|1|follow=0|1 · record follow 0|1 · quality=ultra · keystop=0|1|cambox=0|1|mark=<text>|marktop=0|1|markalign=0-2|marksize=0-2 · record camplace <corner> <size> <round> · record mark <text> · camcolor=r,g,b · record cammove 0|1 · record campos <x> <y>] record start|quality=low|standard|high|mic=0|1|folder=..|hide=0|1  ·  record pause|resume|stop|mic 0|1|status|dialog (session recording to MP4)",
    "cropwindow": "cropwindow [manual|segments|0] (open / close the crop dialog; manual = a fresh manual box around the body)",
    "cropbox": "cropbox [image] (the first manual crop box: around the body, a little inside the edges; voxel ranges x0,x1,y0,y1,z0,z1)",
    "segshow": "segshow all|none|otherstudies <image>|only <image>:<seg> (segmentation visibility in bulk; with no argument: list image:seg=shown)",
    "colorbars": "colorbars [vp] (the colour bars on a view: position as fractions of the view, window, colormap)",
    "mousemove": "mousemove x,y (a real pointer move to window point x,y; for tests)",
    "autohide": "autohide left|right on|off|over|push|state (the image list / tool panel hides itself and opens when the mouse goes to that edge; over = slides over the images, push = pushes them aside)",
    "popout": "popout <tab>[|0] (open a tab in its own window, e.g. segment, registration, ai, dosimetry, batch; |0 = back in the tool panel)",
    "quality3d": "quality3d low|balanced|high (3D view quality presets: samples, resolution, shading)",
    "presskey": "presskey 0..9 (tests: a number key, e.g. the W/L keys of the views)",
    "mouseclick": "mouseclick at=fx,fy|double=1|button=right (tests: a real click / double-click, position as fractions of the window)",
    "typetext": "typetext <text>|selectall=1|enter=1 (tests: real key events into the focused text box)",
    "mousedrag": "mousedrag vp=<i>|from=fx,fy|to=fx,fy|steps=12|button=left (tests: a real mouse drag on a view, positions as fractions of the view)",
    "lesiondose": "lesiondose img=<NM or dose image i>|dose=<i>|seg=<i>:<seg>:<label>|mm=3|scale=1|show=0|outline=1|blink=0 (dose of a lesion from a dose map: mean in the segmentation, and spill-out corrected = sum in the dilated region / voxels of the segmentation)",
    "armsbatch": "armsbatch <CT>;<CT>…|csv=<path>|gen=1|moose=<moose_body model folder> (Batch: generates the MOOSE body segmentation when missing, then the arms position CSV)",
    "sirt": "sirt spect=<i>|liver=<i>:<seg>:<label>|body=<i>:<seg>:<label>|none|activity=2800|lsf=5|residual=2|dilate=0|regions=<i>:<seg>;..",
    "cardiac": "cardiac seg=<i>|label=1|auto=1|angles=x,z[,roll]|images=0,1|other=1|shiftref=1 (short-axis images)",
    "cardiacimage": "cardiacimage image=<i>|auto=1|centre=x,y,z|seg=1 (short axis from the image only: LV centre + axis guess; then cardiac images=<i>)",
    "splash": "splash rows=<SA image>,<SA image>…|left=a;b|right=c;d|n=12|slab=0|zoom=1,1,1|shift=<row>:<view>:<k>|cmap=<row>:<name>|gamma=<row>:<g>|wl=<row|all>:<min>:<max>|wlmode=pct|abs|wlsync=1|lock=0|rowzoom=<row>:<view>:<z>|seg=<row>:<image>:<seg>|ct=<row>:<image>|ctwl=a,b|opacity=a|segopacity=a|notes=<text, \n = new line>|fontscale=1|paper=a4|a3|a5|letter|fit|orient=landscape|portrait|dpi=300|bull=1|bullmode=numbers|image|fused|bullinterp=blocks|interpolated|smoothed|click=<row>:<view>:<slice>|bg=light|dark|theme|notch=<size>:<colour>|rowbull=<row>:0|1|png=<file>|open=1 (cardiac splash view: SA, VLA, HLA rows of up to 4 images)",
    "cardiac17": "cardiac17 percents=29,58,87|margin=1|numbers=aha|width=mid:1:80|bounds=standard (17-segment LV model; width: the neighbours share the change)",
    "relink": "relink seg=<image>:<k>|to=<image>[|copy] (segmentation onto another image) · relink image=<image>|study=<image of that study>|none (image to another study, with its segmentations)",
    "multidrop": "multidrop [dialog;] file|image|fused|seg|on(view, row:k, image:i)|study(keep, new:<name>, existing:i)|nickname; … (several files, each with its role / image / study)",
    "cardiacbull": "cardiacbull value=<i> (bull's-eye table: [segment] lines)",
    "cardiactransfer": "cardiactransfer <i> (17 segments onto a non-reoriented image)",
    "cardiacsave": "cardiacsave <folder> (short axis, segments, transform, CSV)",
    "density": "density classes|bilinear|umap|clip=-1000,3000|unit=g/L|kvp=120 (new image)",
    "brush": "brush <radius mm>|sphere=1|square=0 (selects the brush tool)",
    "body": "body [lower,upper]|min=10|close=1|largest=1|engine=auto|builtin|yazdan|label=0|image=<index>",
    "thrlive": "thrlive lo,hi (live threshold preview of the active label) · thrkeep · thrcancel",
    "overwrite": "overwrite all | none | 2,5 (labels that may be painted over)",
    "nnregion": "nnregion whole | nnregion auto [mm] | nnregion x0,y0,z0,x1,y1,z1 | nnregion grow=0/1",
    "hanging": "hanging [name] | hanging auto=0/1 | hanging save=<name>",
    "saveworkspace": "saveworkspace <file.json>",
    "saveworkspacecopies": "saveworkspacecopies <file.json> – self-contained workspace: a NIfTI copy of every image, segmentation and registration",
    "basket": "basket add|remove <image index> · basket list · basket clear · basket save <folder> – the export basket",
    "loadworkspace": "loadworkspace <file.json>",
    "autosave": "autosave now | autosave wait | autosave <minutes>",
    "exportdicom": "exportdicom <folder>|items=images,seg,rtstruct,sr|attach=1|name=Doe^John|id=P01|study=..|series=..|anonymize=1",
    "exportimages": "exportimages <folder>|items=layout,viewports,axial,coronal,sagittal,3d,gif3d,gifaxial,gifcoronal,gifsagittal|quality=92|delay=80|size=1024|gifsize=512|frames=36|step=0|prefix=name|format=jpg|png",
    "crop": "crop segs=liver,lung|margin=10|margins=r,l,a,p,i,s|axes=lr,ap,si|all=1|replace=0   or   crop box=x0,x1,y0,y1,z0,z1",
    "dvhmetrics": "dvhmetrics V20Gy, D20%, D10ml – extra DVH metrics (table, CSV, printdvh)",
    "dvhwindow": "dvhwindow – open the large DVH plot",
    "dvhcsv": "dvhcsv <path> – DVH + constraints report",
    "constraintpreset": "constraintpreset rlt|sirt|ebrt",
    "addconstraint": "addconstraint <structure>: <expr>  e.g. kidney: Dmean < 23",
    "clearconstraints": "clearconstraints",
    "printconstraints": "printconstraints – PASS / FAIL per structure",
    "isodose": "isodose on|off",
    "isomode": "isomode abs|pct|pctmax",
    "isolevels": "isolevels <list>  e.g. 10,20,30 (Gy) or 50,95,107 (%)",
    "colorwash": "colorwash – show the dose fused on the structure image",
    # roles
    "setrole": "setrole <image index>,image|overlay|seg,<viewport or target image index>",
    "segtoimage": "segtoimage <image index>,<segmentation index>",
    "moveseg": "moveseg <from image>,<segmentation index>,<to image>",
    "syncoverlay": "syncoverlay on|off – same overlay & opacity in all views",
    # misc
    "about": "about",
    "wait": "wait <frames>",
    "sync": "sync – wait until all background jobs are finished",
    "quit": "quit",
}


class OrcaMIError(RuntimeError):
    pass


# ---------------------------------------------------------------- utilities
def find_exe(exe: Optional[str] = None) -> str:
    """Locate ORCA-MI.exe (argument, $ORCAMI_EXE, next to this file, or known build folders)."""
    cands = []
    if exe:
        cands.append(exe)
    for var in ("ORCAMI_EXE",):
        if os.environ.get(var):
            cands.append(os.environ[var])
    here = os.path.dirname(os.path.abspath(__file__))
    cands += [
        os.path.join(here, "ORCA-MI.exe"),
        os.path.join(here, "ORCA-MI.exe"),
        os.path.join(here, "..", "dist", "ORCA-MI.exe"),
        os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "ORCA-MI", "ORCA-MI.exe"),
        os.path.join(os.environ.get("ProgramFiles", r"C:\Program Files"), "ORCA-MI", "ORCA-MI.exe"),
    ]
    for c in cands:
        if c and os.path.isfile(c):
            return os.path.abspath(c)
    found = shutil.which("ORCA-MI") or shutil.which("ORCA-MI.exe")
    if found:
        return found
    raise OrcaMIError("ORCA-MI.exe not found – pass exe=... or set ORCAMI_EXE")


def _fmt(v: Any) -> str:
    if isinstance(v, bool):
        return "on" if v else "off"
    if isinstance(v, (list, tuple)):
        return ",".join(_fmt(x) for x in v)
    return str(v)


def write_nifti(path: str, array, spacing: Sequence[float] = (1.0, 1.0, 1.0), origin: Sequence[float] = (0.0, 0.0, 0.0),
                affine=None, axes: str = "xyz") -> str:
    """Write a 2D/3D/4D numpy array as NIfTI-1 (.nii or .nii.gz) without any dependency but numpy.

    axes: "xyz" (nibabel convention, default) or "zyx" (SimpleITK GetArrayFromImage convention).
    affine: optional 4x4 RAS affine (as from nibabel); otherwise spacing/origin (RAS) are used."""
    import numpy as np

    a = np.asarray(array)
    if a.dtype == bool:
        a = a.astype(np.uint8)
    if a.ndim == 2:
        a = a[:, :, None] if axes == "xyz" else a[None]
    if axes == "zyx":
        # (z, y, x) or (t, z, y, x) -> (x, y, z[, t])
        a = np.transpose(a, (2, 1, 0)) if a.ndim == 3 else np.transpose(a, (3, 2, 1, 0))
    dt_map = {np.dtype(np.uint8): (2, 8), np.dtype(np.int16): (4, 16), np.dtype(np.int32): (8, 32), np.dtype(np.float32): (16, 32),
              np.dtype(np.float64): (64, 64), np.dtype(np.uint16): (512, 16), np.dtype(np.int8): (256, 8), np.dtype(np.uint32): (768, 32)}
    if a.dtype not in dt_map:
        a = a.astype(np.float32)
    code, bitpix = dt_map[a.dtype]
    if affine is None:
        affine = np.eye(4)
        affine[0, 0], affine[1, 1], affine[2, 2] = spacing[0], spacing[1], spacing[2]
        affine[:3, 3] = origin
    affine = np.asarray(affine, dtype=float)
    sp = np.sqrt((affine[:3, :3] ** 2).sum(0))
    h = bytearray(352)
    struct.pack_into("<i", h, 0, 348)
    dims = [a.ndim] + list(a.shape) + [1] * (7 - a.ndim)
    struct.pack_into("<8h", h, 40, *dims)
    struct.pack_into("<hh", h, 70, code, bitpix)
    struct.pack_into("<8f", h, 76, 1.0, sp[0], sp[1], sp[2], 1.0, 1.0, 1.0, 1.0)
    struct.pack_into("<f", h, 108, 352.0)
    struct.pack_into("<ff", h, 112, 1.0, 0.0)
    h[123] = 10
    struct.pack_into("<hh", h, 252, 0, 1)  # qform 0, sform 1
    for r in range(3):
        struct.pack_into("<4f", h, 280 + 16 * r, *[float(x) for x in affine[r]])
    h[344:348] = b"n+1\0"
    data = np.asfortranarray(a).tobytes(order="F")
    opener = gzip.open if path.endswith(".gz") else open
    with opener(path, "wb") as f:
        f.write(bytes(h))
        f.write(data)
    return path


def _as_path(image, tmpdir: str, name: str = "array", **nifti_kw) -> str:
    if isinstance(image, (str, os.PathLike)):
        return os.fspath(image)
    # SimpleITK image?
    if type(image).__name__ == "Image" and hasattr(image, "GetSpacing"):
        import SimpleITK as sitk  # noqa

        p = os.path.join(tmpdir, f"{name}_{int(time.time() * 1000)}.nii.gz")
        sitk.WriteImage(image, p)
        return p
    # nibabel image?
    if hasattr(image, "affine") and hasattr(image, "get_fdata"):
        nifti_kw = dict(nifti_kw)
        nifti_kw["affine"] = image.affine
        image = image.get_fdata(dtype="float32")
    p = os.path.join(tmpdir, f"{name}_{int(time.time() * 1000)}.nii.gz")
    return write_nifti(p, image, **nifti_kw)


def _role_line(kind: str, path: str, colormap=None, opacity=None, palette=None, viewport=None, window=None, name=None,
               labels=None) -> str:
    parts = [path]
    if labels:
        parts.append("labels=" + ";".join(f"{int(k)}:{v}" for k, v in dict(labels).items()))
    if colormap is not None:
        parts.append(f"colormap={colormap}")
    if opacity is not None:
        parts.append(f"opacity={opacity}")
    if palette is not None:
        if isinstance(palette, (tuple, list)) and len(palette) == 3:
            palette = "#%02x%02x%02x" % tuple(int(c) for c in palette)
        parts.append(f"palette={palette}")
    if viewport is not None:
        parts.append(f"vp={viewport}")
    if window is not None:
        parts.append(f"window={window[0]},{window[1]}")
    if name is not None:
        parts.append(f"name={name}")
    return f"{kind} " + "|".join(parts)


# ---------------------------------------------------------------- launch
def launch(*images, overlay=None, seg=None, colormap=None, overlay_colormap=None, overlay_opacity=None, palette=None,
           seg_opacity=None, layout=None, script: Optional[Iterable[str]] = None, listen: Optional[int] = None,
           exe: Optional[str] = None, wait: bool = False, **commands) -> subprocess.Popen:
    """Start ORCA-MI with any combination of command-line options.

    images:   paths / folders / numpy arrays / nibabel / SimpleITK images (shown as images)
    overlay:  path or array fused on the first image;  seg: path or array attached as segmentation
    commands: any viewer command as keyword, e.g. mode3d="dvr", theme="nord", threshold=(2.5, 1000),
              tab="segment", fuse=True. Lists of values repeat the command.
    script:   extra command lines executed in order.
    listen:   also start the Python API server on this port (connect later with Viewer(port=...)).
    """
    tmp = tempfile.mkdtemp(prefix="orcami_")
    lines = []
    for k, im in enumerate(images):
        p = _as_path(im, tmp, f"image{k}")
        lines.append(_role_line("load", p, colormap=colormap if k == 0 else None, viewport=k))
    if overlay is not None:
        lines.append(_role_line("overlay", _as_path(overlay, tmp, "overlay"), colormap=overlay_colormap, opacity=overlay_opacity, viewport=0))
    if seg is not None:
        lines.append(_role_line("seg", _as_path(seg, tmp, "seg"), palette=palette, opacity=seg_opacity, viewport=0))
    if layout is not None:
        lines.append(f"layout {layout}")
    for k, v in commands.items():
        if k not in COMMANDS:
            raise OrcaMIError(f"unknown command '{k}'. Known: {', '.join(sorted(COMMANDS))}")
        vals = v if isinstance(v, list) else [v]
        for x in vals:
            lines.append(k if x is True else f"{k} {_fmt(x)}")
    lines += list(script or [])
    args = [find_exe(exe)]
    if listen:
        args.append(f"--listen={int(listen)}")
    if lines:
        sp = os.path.join(tmp, "script.txt")
        with open(sp, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
        args.append(f"--script={sp}")
    proc = subprocess.Popen(args)
    if wait:
        proc.wait()
    return proc


# ---------------------------------------------------------------- live viewer
class Viewer:
    """Live connection to a running ORCA-MI (started automatically if needed)."""

    def __init__(self, port: int = DEFAULT_PORT, exe: Optional[str] = None, start: bool = True, timeout: float = 60.0,
                 check: bool = True):
        self.port = port
        self.check = check
        self._tmp = tempfile.mkdtemp(prefix="orcami_api_")
        self.proc = None
        self.sock = self._connect(quick=True)
        if self.sock is None:
            if not start:
                raise OrcaMIError(f"no viewer listening on port {port}")
            self.proc = subprocess.Popen([find_exe(exe), f"--listen={port}"])
            t0 = time.time()
            while self.sock is None and time.time() - t0 < timeout:
                time.sleep(0.5)
                self.sock = self._connect(quick=True)
            if self.sock is None:
                raise OrcaMIError("viewer did not start the API server in time")
        self._file = self.sock.makefile("r", encoding="utf-8")
        self.info = self._raw("ping")

    def _connect(self, quick=False):
        try:
            s = socket.create_connection(("127.0.0.1", self.port), timeout=1.0 if quick else 10.0)
            s.settimeout(None)
            return s
        except OSError:
            return None

    def _raw(self, line: str) -> dict:
        self.sock.sendall((line.replace("\n", " ") + "\n").encode("utf-8"))
        reply = self._file.readline()
        if not reply:
            raise OrcaMIError("connection to the viewer was closed")
        return json.loads(reply)

    # -- generic
    def command(self, line: str, check: Optional[bool] = None) -> dict:
        """Send one command line (see help()). Blocks until it (and its background jobs) finished."""
        r = self._raw(line)
        if (self.check if check is None else check) and not r.get("ok", False):
            raise OrcaMIError(r.get("error") or "command failed")
        return r

    def run(self, lines: Iterable[str]) -> list:
        """Send several command lines; returns the replies."""
        return [self.command(l) for l in lines]

    def __call__(self, line: str) -> dict:
        return self.command(line)

    def __getattr__(self, name: str):
        if name.startswith("_"):
            raise AttributeError(name)

        def f(*args):
            return self.command(name if not args else f"{name} {_fmt(list(args)) if len(args) > 1 else _fmt(args[0])}")

        f.__doc__ = COMMANDS.get(name, "viewer command")
        return f

    @staticmethod
    def help(show: bool = True) -> dict:
        if show:
            for k in sorted(COMMANDS):
                print(f"{k:16s} {COMMANDS[k]}")
        return COMMANDS

    # -- loading with roles
    def load(self, image, role: str = "image", colormap: Optional[str] = None, opacity: Optional[float] = None,
             palette=None, viewport: Optional[int] = None, window: Optional[Sequence[float]] = None,
             name: Optional[str] = None, spacing=(1.0, 1.0, 1.0), origin=(0.0, 0.0, 0.0), affine=None,
             axes: str = "xyz", labels: Optional[dict] = None) -> dict:
        """Load a path / numpy array / nibabel / SimpleITK image.

        role:     "image" | "overlay" | "seg"
        colormap: e.g. "grayscale", "hot iron", "pet", "jet", "viridis" (image / overlay)
        palette:  segmentation colors: "distinct", a colormap name, "#ff0000", "red", or an (r, g, b) tuple
        opacity:  overlay / segmentation opacity (0..1)
        viewport: target viewport index (the layout grows if needed)
        window:   (lo, hi) display window
        labels:   {value: name} label names for segmentations (e.g. {1: "spleen", 2: "kidney_right"})
        spacing/origin/affine/axes: geometry for numpy arrays (axes="zyx" for SimpleITK-ordered arrays)
        Returns the reply; reply["index"] is the image index in the viewer."""
        kind = {"image": "load", "overlay": "overlay", "fusion": "overlay", "seg": "seg", "segmentation": "seg",
                "label": "seg", "mask": "seg"}.get(role.lower())
        if kind is None:
            raise OrcaMIError(f"unknown role {role!r} (image, overlay, seg)")
        p = _as_path(image, self._tmp, name or role, spacing=spacing, origin=origin, affine=affine, axes=axes)
        r = self.command(_role_line(kind, p, colormap, opacity, palette, viewport, window, name, labels))
        for l in r.get("log", []):
            if l.startswith("[loaded]"):
                kv = dict(x.split("=", 1) for x in l.split()[1:] if "=" in x)
                r["index"] = int(kv.get("index", -1))
                r["id"] = int(kv.get("id", -1))
        return r

    def overlay(self, image, **kw) -> dict:
        return self.load(image, role="overlay", **kw)

    def segmentation(self, image, **kw) -> dict:
        return self.load(image, role="seg", **kw)

    # -- typed helpers
    def images(self) -> list:
        """Loaded images as a list of dicts."""
        out = []
        for l in self.command("listimages").get("log", []):
            if l.startswith("[image]"):
                d = {}
                rest = l[len("[image] "):]
                # name may contain spaces: parse known keys
                keys = ["index", "id", "name", "modality", "unit", "dims", "spacing", "frames", "segmentations", "colormap"]
                pos = [(rest.find(k + "="), k) for k in keys]
                pos = sorted(p for p in pos if p[0] >= 0)
                for i, (p, k) in enumerate(pos):
                    end = pos[i + 1][0] if i + 1 < len(pos) else len(rest)
                    d[k] = rest[p + len(k) + 1:end].strip()
                for k in ["index", "id", "frames", "segmentations"]:
                    if k in d:
                        d[k] = int(d[k])
                out.append(d)
        return out

    def stats(self, value_image: Optional[int] = None, split: bool = False) -> list:
        """Statistics of every label of the active segmentation: volume_ml (MTV), mean (SUVmean), max (SUVmax),
        peak (SUVpeak, 1 mL sphere), tlg (mean x volume = TLG on SUV images), std, min, median, voxels.

        value_image: index of the image whose values are measured (e.g. the PET when the mask is on the CT).
        split: report every connected lesion separately ("name #1", "name #2", ...)."""
        opts = []
        if value_image is not None:
            opts.append(f"value={value_image}")
        if split:
            opts.append("split=1")
        out = []
        for l in self.command(("stats " + "|".join(opts)).strip()).get("log", []):
            if l.startswith("[stats]"):
                # "[stats] label 1 Name: 32.957 mL mean 7.48 max 10.93 peak 10.25 std 2.45 ... tlg 246.5 voxels 1234"
                head, tail = l[len("[stats] label "):].split(":", 1)
                lab, _, name = head.partition(" ")
                t = tail.split()
                d = {"label": int(lab), "name": name.replace("_", " "), "volume_ml": float(t[0])}
                for i in range(2, len(t) - 1, 2):
                    try:
                        d[t[i]] = float(t[i + 1])
                    except ValueError:
                        pass
                out.append(d)
        return out

    def metrics(self, a_image: int, a_seg: int, a_label: int, b_image: int, b_seg: int, b_label: int) -> dict:
        """Dice, Jaccard, Hausdorff, HD95, ASSD, ... between two segmentations (indices)."""
        self.command(f"metrics {a_image},{a_seg},{a_label},{b_image},{b_seg},{b_label}")
        res = {}
        for l in self.command("printmetrics").get("log", []):
            if l.startswith("[metrics]   "):
                k, _, v = l[len("[metrics]   "):].partition(": ")
                try:
                    res[k] = float(v.split()[0])
                except ValueError:
                    res[k] = v
        return res

    def dvh(self, dose: Optional[int] = None, structures: Optional[Sequence[int]] = None, rx: Optional[float] = None,
            scale: Optional[float] = None, metrics: Optional[str] = None) -> list:
        """Compute DVHs and return per-structure metrics (Gy, cc).
        dose: dose image index; structures: (image index, segmentation index); rx: prescription Gy;
        scale: factor to Gy (0.01 for cGy).
        metrics: extra DVH metrics, e.g. "V20Gy, D20%, D10ml, V5Gy cc" (keys: V20Gy, D20%, D10cc, V5Gy_cc)."""
        if metrics is not None:
            self.command(f"dvhmetrics {metrics}")
        if dose is not None:
            self.command(f"dose {dose}")
        if structures is not None:
            self.command(f"structures {structures[0]},{structures[1] if len(structures) > 1 else 0}")
        if rx is not None:
            self.command(f"rx {rx}")
        if scale is not None:
            self.command(f"dosescale {scale}")
        self.command("dvh")
        out = []
        for l in self.command("printdvh").get("log", []):
            if l.startswith("[dvh]"):
                d = dict(x.split("=", 1) for x in l.split()[1:] if "=" in x)
                for k in list(d):
                    if k not in ("name",):
                        try:
                            d[k] = float(d[k])
                        except ValueError:
                            pass
                d["label"] = int(d["label"])
                out.append(d)
        return out

    def constraints(self, add: Optional[Sequence[str]] = None, preset: Optional[str] = None) -> list:
        """Evaluate DVH constraints. add: ["kidney: Dmean < 23", ...]; preset: "rlt", "sirt" or "ebrt"."""
        if preset:
            self.command(f"constraintpreset {preset}")
        for c in add or []:
            self.command(f"addconstraint {c}")
        out = []
        for l in self.command("printconstraints").get("log", []):
            if l.startswith("[constraint]"):
                d = dict(x.split("=", 1) for x in l.split()[1:] if "=" in x)
                for k in ("value", "limit"):
                    d[k] = float(d[k])
                d["pass"] = d.get("result") == "PASS"
                out.append(d)
        return out

    def isodose(self, levels: Sequence[float], percent: bool = False, reference: str = "rx", on: bool = True) -> dict:
        """Show isodose lines; levels in Gy, or in % of the prescription (reference="rx") or max dose."""
        self.command("isomode " + ("pct" + ("max" if reference == "max" else "") if percent else "abs"))
        self.command("isolevels " + ",".join(str(x) for x in levels))
        return self.command("isodose " + ("on" if on else "off"))

    def set_role(self, image: int, role: str, target: Optional[int] = None) -> dict:
        """Change the role of a loaded image: role image|overlay (target = viewport) or seg (target = image index)."""
        return self.command(f"setrole {image},{role}" + (f",{target}" if target is not None else ""))

    def transform(self) -> str:
        r = self.command("printtransform")
        return next((l for l in r.get("log", []) if l.startswith("[transform]")), "")

    def run_ai(self, preset: int = 0, model: Optional[str] = None, image: Optional[int] = None) -> dict:
        """Run an AI preset (index in the AI tab) on the active image (or image index)."""
        if image is not None:
            self.command(f"select {image}")
        self.command(f"aipreset {preset}")
        if model:
            self.command(f"aimodel {model}")
        return self.command(f"ai {preset}")

    # ------------------------------------------------------------ presentation export & cropping

    EXPORT_ITEMS = ("layout", "viewports", "axial", "coronal", "sagittal", "3d", "gif3d", "gifaxial", "gifcoronal", "gifsagittal")

    def export_images(self, folder: str, items: Sequence[str] = ("layout", "axial", "coronal", "sagittal", "3d"),
                      quality: int = 92, gif_delay_ms: int = 80, size: int = 1024, gif_size: int = 512,
                      gif_frames: int = 36, cine_step: int = 0, prefix: Optional[str] = None, png: bool = False) -> list:
        """Save presentation images and GIFs of the current scene; returns the written file paths.

        items (any of):
          layout       the whole viewing area exactly as displayed (2x2, several 3D views, ...)
          viewports    each view as displayed, one file per view
          axial, coronal, sagittal   clean high-resolution renders of the active view's image (+ fusion
                       overlay + segmentations) at the cursor, correct aspect ratio
          3d           every 3D view at high resolution with its current camera
          gif3d        all 3D views turning together (as arranged on screen)
          gifaxial, gifcoronal, gifsagittal   cine through all slices
        quality: JPEG quality (1-100); png=True writes lossless PNG instead.
        gif_delay_ms: GIF speed (ms per frame); gif_frames: frames per 3D turn; cine_step: slice step (0 = auto).
        size / gif_size: longest side in pixels of still images / GIF frames.
        prefix: file name prefix (default: image name + date/time)."""
        bad = [i for i in items if i not in self.EXPORT_ITEMS]
        if bad:
            raise OrcaMIError(f"unknown export items {bad}; use {self.EXPORT_ITEMS}")
        os.makedirs(folder, exist_ok=True)
        line = (f"exportimages {os.path.abspath(folder)}|items={','.join(items)}|quality={int(quality)}|delay={int(gif_delay_ms)}"
                f"|size={int(size)}|gifsize={int(gif_size)}|frames={int(gif_frames)}|step={int(cine_step)}|format={'png' if png else 'jpg'}")
        if prefix:
            line += f"|prefix={prefix}"
        r = self.command(line)
        return [l[len("[export] "):] for l in r.get("log", []) if l.startswith("[export] ")]

    def iterative_segmentation(self, value_image: int = 1, seg_image: int = 0, mode: str = "lesions",
                               box_margin_mm: float = 10.0, plateau_pct: float = 2.0, post_plateau: int = 10,
                               max_iter: int = 500, step=0.1, min_volume_ml: float = 0.0,
                               keep_largest: bool = True, inside_initial_region: bool = True,
                               crop_margin_mm: float = 5.0, seg_index: int = 0) -> list:
        """Iterative threshold segmentation (XEOS method) of every lesion; returns one dict per lesion
        (label, name, threshold, volume_ml, mean, max, iterations). The result is a segmentation named
        "Iterative segmentation" on the value image.

        value_image: index of the PET (values); seg_image / seg_index: the initial segmentation.
        mode: "lesions" (each connected lesion), "labels" (each label) or "boxes" (a box of
              box_margin_mm around each lesion).
        step: threshold step in display units (SUV, or kBq/mL for Bq/mL images) or "auto"."""
        line = (f"iterative value={value_image}|seg={seg_image}|segindex={seg_index}|mode={mode}|margin={box_margin_mm}"
                f"|plateau={plateau_pct}|post={post_plateau}|maxiter={max_iter}|step={step}|minvol={min_volume_ml}"
                f"|largest={int(keep_largest)}|rough={int(inside_initial_region)}|crop={crop_margin_mm}")
        return self._iter_rows(self.command(line))

    def iterative_threshold(self, lesion: int, threshold="auto") -> list:
        """Set the threshold of one lesion (1-based index, or "auto" for the plateau value)."""
        return self._iter_rows(self.command(f"iterthreshold {lesion},{threshold}"))

    @staticmethod
    def _iter_rows(r: dict) -> list:
        # "[iterative] lesion 1 name=Lesion_1 threshold 2.1 volume_ml 3.4 mean 5.6 max 9.1 iterations 42"
        out = []
        for l in r.get("log", []):
            if l.startswith("[iterative] lesion "):
                t = l[len("[iterative] lesion "):].split()
                d = {"label": int(t[0]), "name": t[1][len("name="):].replace("_", " ")}
                for k in range(2, len(t) - 1, 2):
                    try:
                        d[t[k]] = float(t[k + 1])
                    except ValueError:
                        pass
                out.append(d)
        return out

    def dynamic_tac(self, frames: Optional[int] = None, images: Optional[Sequence[int]] = None, reference: int = 0,
                    seg_image: Optional[int] = None, times: Optional[Sequence[float]] = None,
                    durations: Optional[Sequence[float]] = None, time_unit: Optional[str] = None,
                    register: bool = False, register_from: int = 0, metric: str = "ncc",
                    input_label: int = 0, t_star: float = 10.0, tail_points: int = 2, csv: Optional[str] = None,
                    ki_map: bool = False, corrected_copy: bool = False) -> dict:
        """Time-activity curves per segment label.

        frames:   index of one 4D image (dynamic PET)            — or —
        images:   indices of 3D images, one per time point (e.g. SPECT day 1, 2, 3)
        reference: frame / time point the others are registered to; the ROIs are the active segmentation of
                  seg_image (default: the reference image)
        times / durations: frame start and duration (default from DICOM: minutes for frames, hours for images)
        register: rigid registration of every frame / time point to the reference (motion correction)
        input_label: label of the input function (e.g. aorta) → Patlak Ki / V0 for all other labels (t >= t_star)
        tail_points: points of the mono-exponential fit for the effective half-life and the TIA (time points)
        ki_map: add a voxel-wise Patlak Ki image; corrected_copy: add the motion-corrected 4D image
        Returns {"tac": [...], "patlak": [...], "kinetics": [...], "motion": [...]}."""
        parts = []
        if frames is not None:
            parts.append(f"frames={int(frames)}")
        if images is not None:
            parts.append("images=" + ",".join(str(int(i)) for i in images))
        parts.append(f"ref={int(reference)}")
        if seg_image is not None:
            parts.append(f"seg={int(seg_image)}")
        if times is not None:
            parts.append("times=" + ",".join(f"{float(t):.6f}" for t in times))
        if durations is not None:
            parts.append("durations=" + ",".join(f"{float(t):.6f}" for t in durations))
        if time_unit:
            parts.append(f"unit={time_unit}")
        parts += [f"register={int(register)}", f"from={int(register_from)}", f"metric={metric}", f"input={int(input_label)}",
                  f"tstar={float(t_star)}", f"tail={int(tail_points)}", f"kimap={int(ki_map)}", f"corrected={int(corrected_copy)}"]
        if csv:
            parts.append(f"csv={os.path.abspath(csv)}")
        r = self.command("dynamic " + "|".join(parts))

        def kv(line):
            d = {}
            for x in line.split()[1:]:
                if "=" in x:
                    k, v = x.split("=", 1)
                    try:
                        d[k] = float(v) if k not in ("name",) else v
                    except ValueError:
                        d[k] = v
            return d
        out = {"tac": [], "patlak": [], "kinetics": [], "motion": []}
        for l in r.get("log", []):
            for key in out:
                if l.startswith(f"[{key}]"):
                    out[key].append(kv(l))
        return out

    def nn_region(self, mode: str = "auto", size_mm: Optional[float] = None, box: Optional[Sequence[int]] = None,
                  grow: Optional[bool] = None) -> dict:
        """nnInteractive inference region: mode "auto" (box of size_mm around the first prompt), "whole", or
        box=(x0, y0, z0, x1, y1, z1) in voxels (the object is kept inside it). grow: enlarge automatically."""
        if grow is not None:
            self.command(f"nnregion grow={int(grow)}")
        if box is not None:
            return self.command("nnregion " + ",".join(str(int(b)) for b in box))
        return self.command(f"nnregion {mode} {size_mm if size_mm else ''}".strip())

    def body_contour(self, lower: float = -300, upper: float = 2000, min_ml: float = 10, close_voxels: int = 1,
                     keep_largest: bool = True, engine: str = "builtin", as_label: bool = False) -> dict:
        """Body contour of the active image: yazdan.image.body_segment (engine="yazdan", runs the package in Python) or
        its built-in port (engine="builtin", the default: identical voxels, about 100x faster).
        Adds a segmentation 'Body contour' (or label 'body' in the active segmentation with as_label=True).
        Returns {"voxels": .., "volume_ml": .., "engine": ..}."""
        r = self.command(f"body {lower},{upper}|min={min_ml}|close={int(close_voxels)}|largest={int(keep_largest)}"
                         f"|engine={engine}|label={int(as_label)}")
        for l in r.get("log", []):
            if l.startswith("[body]"):
                d = dict(x.split("=", 1) for x in l.split()[1:] if "=" in x)
                return {"voxels": int(d.get("voxels", 0)), "volume_ml": float(d.get("volume_ml", 0)), "engine": d.get("engine", "")}
        return r

    def hanging_protocol(self, name: str = "") -> dict:
        """Apply the hanging protocol whose name contains `name` (empty: the first matching one)."""
        return self.command(f"hanging {name}".strip())

    def save_workspace(self, path: str) -> dict:
        """Save images, display, segmentations (NIfTI next to the JSON), annotations and the screen."""
        return self.command(f"saveworkspace {os.path.abspath(path)}")

    def load_workspace(self, path: str) -> dict:
        return self.command(f"loadworkspace {os.path.abspath(path)}")

    def export_dicom(self, folder: str, items: Sequence[str] = ("images", "seg", "rtstruct", "sr"), attach_to_original: bool = True,
                     patient_name: Optional[str] = None, patient_id: Optional[str] = None, birth_date: Optional[str] = None,
                     sex: Optional[str] = None, accession: Optional[str] = None, study_description: Optional[str] = None,
                     series_description: Optional[str] = None, series_number: int = 901, anonymize: bool = False) -> list:
        """Export the active image and its segmentation for PACS: image series, DICOM SEG, RTSTRUCT and a
        measurement SR (values from the image chosen with stats(value_image=...)). Returns the written paths.

        attach_to_original: put the results into the original DICOM study (references its slices).
        anonymize: ANONYMOUS / new ID / no birth date and a new study."""
        line = f"exportdicom {os.path.abspath(folder)}|items={','.join(items)}|attach={int(attach_to_original)}|number={int(series_number)}"
        for key, val in (("name", patient_name), ("id", patient_id), ("birth", birth_date), ("sex", sex),
                         ("accession", accession), ("study", study_description), ("series", series_description)):
            if val is not None:
                line += f"|{key}={val}"
        if anonymize:
            line += "|anonymize=1"
        r = self.command(line)
        return [l[len("[dicomexport] "):] for l in r.get("log", []) if l.startswith("[dicomexport] ")]

    def show_3d(self, image: bool = True, segments: bool = True) -> dict:
        """Show / hide the image volume and the segmentation in the 3D views (image off = surfaces only, faster)."""
        return self.command(f"show3d image={int(image)}|seg={int(segments)}")

    def crop_to_segments(self, segments: Optional[Sequence[str]] = None, margin: float = 10.0,
                         margins: Optional[dict] = None, axes: str = "LR,AP,SI", all_images: bool = True,
                         replace: bool = False, seg: Optional[int] = None) -> list:
        """Crop to the box around segments of the active image (+ margin) and return the new image indices.

        segments: label names (substring, case-insensitive) or label numbers, e.g. ["lung", "liver"];
                  None = every label.
        margin:   mm added on every side; margins: per direction, e.g. {"S": 30, "I": 10} (keys R L A P I S),
                  directions not given use `margin`.
        axes:     which directions are cropped: "SI" crops only head-feet, "LR,AP,SI" all three.
        all_images: crop every loaded image (CT, PET, dose ...) to the same physical box.
        replace:  remove the originals (default: cropped copies are added and shown)."""
        m = {k: float(margin) for k in "RLAPIS"}
        for k, v in (margins or {}).items():
            m[k.upper()[0]] = float(v)
        opts = [f"margins={m['R']},{m['L']},{m['A']},{m['P']},{m['I']},{m['S']}",
                f"axes={axes.replace(' ', '').lower()}", f"all={int(all_images)}", f"replace={int(replace)}"]
        if segments:
            opts.insert(0, "segs=" + ",".join(str(x) for x in segments))
        if seg is not None:
            opts.append(f"seg={seg}")
        return self._cropped(self.command("crop " + "|".join(opts)))

    def crop_box(self, x: Sequence[int], y: Sequence[int], z: Sequence[int], all_images: bool = True,
                 replace: bool = False) -> list:
        """Crop to a voxel box of the active image: x=(from, to), y=..., z=... (end exclusive)."""
        b = ",".join(str(int(v)) for v in (*x, *y, *z))
        return self._cropped(self.command(f"crop box={b}|all={int(all_images)}|replace={int(replace)}"))

    @staticmethod
    def _cropped(r: dict) -> list:
        for l in r.get("log", []):
            if l.startswith("[cropped] "):
                return [int(v) for v in l[len("[cropped] "):].split(",") if v.strip()]
        return []

    def snapshot(self, path: str) -> str:
        self.command(f"snapshot {path}")
        return path

    def close(self, quit_viewer: bool = True):
        try:
            if quit_viewer:
                self._raw("quit")
        except Exception:
            pass
        try:
            self.sock.close()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()


if __name__ == "__main__":
    # tiny CLI: python orcami.py image.nii.gz [--overlay pet.nii.gz] [--seg seg.nii.gz] [--layout mpr]
    import argparse

    ap = argparse.ArgumentParser(description="Launch ORCA-MI")
    ap.add_argument("images", nargs="*")
    ap.add_argument("--overlay")
    ap.add_argument("--seg")
    ap.add_argument("--layout")
    ap.add_argument("--palette")
    ap.add_argument("--colormap")
    ap.add_argument("--commands", action="store_true", help="list all commands")
    a = ap.parse_args()
    if a.commands:
        Viewer.help()
        sys.exit(0)
    launch(*a.images, overlay=a.overlay, seg=a.seg, layout=a.layout, palette=a.palette, colormap=a.colormap)

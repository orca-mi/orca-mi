ORCA-MI 0.1.0 - portable

Double-click ORCA-MI.exe. No installation and no administrator rights are needed.
If Windows SmartScreen warns about an unknown publisher: More info -> Run anyway.

orcami.py   Python API (import orcami as om), keep it next to ORCA-MI.exe
examples\   Python examples
docs\       user guide (also in the program: Help -> User guide) and third-party licences

For research use only. Not a certified medical device. See LICENSE.txt.
https://github.com/orca-mi/orca-mi
